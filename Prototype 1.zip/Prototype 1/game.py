from cards import heart_cards, club_cards, spade_cards, diamond_cards
import random
import time

card_hidden = [
        "xxxxxxxxxxxxxxX",
        "x ??          x",
        "x             x",
        "x             x",
        "x             x",
        "x      ?      x",
        "x             x",
        "x             x",
        "x             x",
        "x          ?? x",
        "xxxxxxxxxxxxxxx"
    ]

card_height = 11
card_width = 15

card_suits = ("heart", "club", "diamond", "spade")
card_ranks = ("ace", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "king", "queen", "jack")
card_values = ([1,11], 2, 3 , 4, 5, 6, 7 , 8, 9, 10, 10 ,10 ,10)

class Player:
    def __init__(self):
        self.hands = []
        self.cards_values = 0
        self.credit = 10000

    def bet(self, bet_amount):
        if (bet_amount > self.credit):
            print("Not Enough Credit(s)!!!")
            return
        else:
            self.credit -= bet_amount

        return bet_amount

    def hit(self, deck):
        self.hands.append(deck.pop(0))
        self.calculate_deck()


    def calculate_deck(self):
        total_value = 0

        count_ace = 0
        for card in self.hands:
            if (card.rank != "ace"):
                total_value += card.value
            else:
                count_ace += 1
                
        total_value += count_ace

        if (count_ace == 0):
            pass
        else:
            for i in range(count_ace):
                if (total_value + 10 <= 21):
                    total_value += 10

        self.cards_values = total_value
    
    def checkBust(self):
        self.calculate_deck()
        if (self.cards_values > 21):
            return True
        else:
            return False

    def display_card(self):
        if (len(self.hands) > 6):
            temp_len = 6
        else:
            temp_len = len(self.hands)

        for i in range(card_height):
            for card in self.hands[:temp_len]:
                print(card.card_display[i], end="  ")
            print()

        if (len(self.hands) > 6):
            for i in range(card_height):
                for card in self.hands[temp_len:len(self.hands)]:
                    print(card.card_display[i], end="  ")
                print()

        return

class Dealer:
    def __init__(self):
        self.hands = []
        self.cards_values = 0
        self.credit = 10000

    def bet(self):
        bet_amount = random.randint(1, int(self.credit/100)) * 100
        self.credit -= bet_amount

        return bet_amount

    def hit(self, deck):
        self.hands.append(deck.pop(0))
        self.calculate_deck()

    def calculate_deck(self):
        total_value = 0

        count_ace = 0
        for card in self.hands:
            if (card.rank != "ace"):
                total_value += card.value
            else:
                count_ace += 1
                
        total_value += count_ace

        if (count_ace == 0):
            pass
        else:
            for i in range(count_ace):
                if (total_value + 10 <= 21):
                    total_value += 10

        self.cards_values = total_value
            
    def checkBust(self):
        self.calculate_deck()
        if (self.cards_values > 21):
            return True
        else:
            return False

    def display_card(self):
        if (len(self.hands) > 6):
            temp_len = 6
        else:
            temp_len = len(self.hands)

        for i in range(card_height):
            for card in self.hands[:temp_len]:
                print(card.card_display[i], end="  ")
            print()

        if (len(self.hands) > 6):
            for i in range(card_height):
                for card in self.hands[temp_len:len(self.hands)]:
                    print(card.card_display[i], end="  ")
                print()

        return

    def display_card_hidden(self):
        for i in range(card_height):
            print(self.hands[0].card_display[i], end="  ")
            print(card_hidden[i])

        return

class Card:
    def __init__(self, rank, value, card_display):
        self.rank = rank
        self.value = value
        self.card_display = card_display

        # self.next = None

class Heart(Card):
    def __init__(self, rank, value, card_display):
        super().__init__(rank, value, card_display)
        self.suit = "heart"

class Club(Card):
    def __init__(self, rank, value, card_display):
        super().__init__(rank, value, card_display)
        self.suit = "club"

class Diamond(Card):
    def __init__(self, rank, value, card_display):
        super().__init__(rank, value, card_display)
        self.suit = "diamond"

class Spade(Card):
    def __init__(self, rank, value, card_display):
        super().__init__(rank, value, card_display)
        self.suit = "spade"

class CardDeck:
    def __init__(self, deck):
        self.card_deck = deck
        self.card_total = len(self.card_deck)

    def shuffle_deck(self):
        random.shuffle(self.card_deck)

    def deal_card(self):
        return self.card_deck.pop(0)
    
class CardDeckProto:
    def __init__(self):
        self.head = None

    def append_deck(self, card):
        if (self.head == None):
            self.head = card
            return
        temp_head = self.head

        while (temp_head.next != None):
            temp_head = temp_head.next

        temp_head.next = card

    def pop_head(self):
        pop_card = self.head
        self.head = self.head.next

    def shuffle_deck(self):
        random.shuffle(self.card_deck)

    def deal_card(self):
        dealed_card = self.head
        self.head = self.head.next
        return dealed_card
    
class Tabel:
    def __init__(self, deck):
        self.pot = 0
        self.deck = deck

    def starting_deal(self, player, dealer):
        self.deck.shuffle_deck()
        for i in range(2):
            player.hands.append(self.deck.deal_card())
            dealer.hands.append(self.deck.deal_card())
            
    
    def add_pot(self, total):
        self.pot += total

    def empty_pot(self):
        give_pot = self.pot
        self.pot = 0

        return give_pot

def updateCardDeck():
    temp_deck = []

    for suit in card_suits:
        for i in range(len(card_ranks)):
            if (suit == "heart"):
                newCard = Heart(card_ranks[i], card_values[i], heart_cards[i])
            elif (suit == "club"):
                newCard = Club(card_ranks[i], card_values[i], club_cards[i])
            elif (suit == "diamond"):
                newCard = Diamond(card_ranks[i], card_values[i], diamond_cards[i])
            elif (suit == "spade"):
                newCard = Spade(card_ranks[i], card_values[i], spade_cards[i])

            temp_deck.append(newCard)

    return temp_deck

const_card_deck = updateCardDeck()

def blackjack_menu():
    
    start = str(input("Start the game? (y/n) : "))

    if (start.lower() == 'n'):
        return
    
    while True:
        newPlayer = Player()
        newDealer = Dealer()
        
        play_table = Tabel(CardDeck(const_card_deck)) 

        isHit_dealer = True
        isHit_player = True
        playerBust = False
        dealerBust = False

        play_table.starting_deal(newPlayer, newDealer)


        # ----------------- PLAYER'S TURN ------------------
        while (isHit_player == True):

            # PLAYER TURN FINISHES WHEN PLAYER BUSTED
            if (playerBust == True):
                break

            print()
            print("========== Player ==========")
            newPlayer.display_card()
            print()
            print("========== Dealer ==========")
            newDealer.display_card_hidden()
            print()

            option = input("1. STAY\t\t2. HIT\t\t3. EXIT\t : ")

            if (option == "1" or option.upper() == "STAY" or playerBust == True):
                isHit_player = False

            elif (option == "2" or option.upper() == "HIT"):
                
                newPlayer.hit(play_table.deck.card_deck)
                playerBust = newPlayer.checkBust()

            elif (option == "3" or option.upper() == "EXIT"):
                playerBust = True
                break

            if (isHit_player == True):
                print("Player decided to HIT", end="")
            else:
                print("Player decided to STAY", end="")
            for i in range(3):
                time.sleep(1)
                print(" .", end="")
            time.sleep(1)
            print()

        if (playerBust == True):
            # IF PLAYER BUSTED BEFORE DEALER'S TURN (PLAYER LOSE)
            game_aftermath(newPlayer, newDealer, playerBust, dealerBust)
        else:

            # ----------------- DEALER'S TURN ------------------

            while (isHit_dealer == True):
                print()
                print("========== Player ==========")
                newPlayer.display_card()
                print()
                print("========== Dealer ==========")
                newDealer.display_card()
                print()

                newDealer.calculate_deck()
                if (newDealer.cards_values == 21):
                    isHit_dealer = False
                elif (newDealer.checkBust() == True):
                    dealerBust = True
                    isHit_dealer = False
                else:
                    newDealer.hit(play_table.deck.card_deck)
                
                if (isHit_dealer == True):
                    print("Dealer decided to HIT", end="")
                else:
                    print("Dealer decided to STAY", end="")
                for i in range(3):
                    time.sleep(1)
                    print(" .", end="")
                time.sleep(1)
                print()

            game_aftermath(newPlayer, newDealer, playerBust, dealerBust) 

        new_game = str(input("Continue? (y/n) : "))  
        print()

        if (new_game == 'n'):
            break
    
    return

def game_aftermath(player, dealer, isBust_player, isBust_dealer):
    print("========== Player ==========")
    player.display_card()
    print()
    print("========== Dealer ==========")
    dealer.display_card()
    print()

    if (isBust_dealer == True and isBust_player == False):
        print("DEALER BUSTED !!! YOU WIN !!!")
    elif (isBust_dealer == False and isBust_player == True):
        print("YOU BUSTED !!! DEALER WINS !!!")
    elif (isBust_dealer == False and isBust_player == False):
        if (dealer.cards_values > player.cards_values):
            print("DEALER WINS !!!")
        elif (dealer.cards_values < player.cards_values):
            print("YOU WIN !!!")
        elif (dealer.cards_values == player.cards_values):
            if (len(dealer.hands) < len(player.hands)):
                print("DEALER WINS !!!")
            elif (len(dealer.hands) > len(player.hands)):
                print("YOU WIN !!!")
            elif (len(dealer.hands) == len(player.hands)):
                print("IT'S A TIE !!!")


def main():

    while True:
        print(f"========== BLACKJACK ==========")
        print(f"1. PLAY BLACKJACK")
        print(f"2. EXIT")
        print(f"===============================")
        option = input("Masukkan opsi : ")
        
        if (option == "1"):
            blackjack_menu()
        elif (option == "2"):
            break





main()
    